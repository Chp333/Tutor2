module.exports = {
  guestcar: require("./guestCar"),
  homeOwner: require("./homeOwner"),
  users: require("./users")
};
