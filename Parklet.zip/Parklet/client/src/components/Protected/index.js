export { default } from "./Protected";

