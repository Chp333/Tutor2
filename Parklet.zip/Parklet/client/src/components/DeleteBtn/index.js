export { default } from "./DeleteBtn";
